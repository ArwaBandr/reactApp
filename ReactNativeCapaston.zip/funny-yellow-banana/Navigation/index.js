import React from "react";
import Navigation from "./navigation";

const Naviagtion = () => <Navigation />;

export default Naviagtion;